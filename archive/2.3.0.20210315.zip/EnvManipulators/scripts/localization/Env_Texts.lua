local texts = EnvMod_Texts

return {
    EnvMechPrime = texts.mech_prime_name,
    EnvMechRanged = texts.mech_ranged_name,
    EnvMechScience = texts.mech_science_name,
    EnvArtificial_Name = texts.envArtificial_name,
    EnvArtificial_Text = texts.envArtificial_description,
    EnvArtificial_StratText = texts.envArtificial_name,
    EnvArtificial_CombatName = texts.envArtificial_name
}
