return {
    squad_name = "环境操纵者",
    squad_description = "这些机甲拥有操纵环境的能力，它们利用环境与敌人战斗。",
    mech_prime_name = "移位机甲",
    mech_ranged_name = "环境机甲",
    mech_science_name = "波导机甲",
    envArtificial_name = "人造环境",
    envArtificial_description = "造成 3 点基础伤害。飞行单位和稳如泰山单位额外受到 1 点伤害。",
    envArtificial_template_description = "造成 3 点基础伤害。飞行单位和稳如泰山单位额外受到 1 点伤害。（当前：%d）",
    envArtificial_disabled = "环境加载器无法工作",
    heavy_title = "重型",
    heavy_description = "重型单位无法享受移动力加成，且在移动力耗尽时受到 1 点伤害。但是它们能将非临时移动力加成转化为护盾。",
    heavy_alert = "重型：移动力加成转化为护盾",
    action_terminated = "行动终止",
    add_to_shop = "添加%s到商店"
}
