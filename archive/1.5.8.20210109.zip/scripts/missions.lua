-- 这种关卡不要出击杀任务，基本做不了的
Mission_Tides.BonusPool = {BONUS_GRID, BONUS_MECHS} -- 巨浪
Mission_Cataclysm.BonusPool = {BONUS_GRID, BONUS_MECHS} -- 灾变
Mission_Crack.BonusPool = {BONUS_GRID, BONUS_MECHS} -- 地震活动
Mission_SnowStorm.BonusPool = {BONUS_GRID, BONUS_MECHS, BONUS_BLOCK} -- 冰风暴

local Missions = {}

return Missions