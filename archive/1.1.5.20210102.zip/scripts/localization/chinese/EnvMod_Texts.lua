EnvMod_Texts = {
    squad_name = "环境操纵者",
    squad_description = "这些机甲拥有操纵环境的能力，它们利用环境与敌人战斗。",
    mech_prime_name = "移位机甲",
    mech_ranged_name = "环境机甲",
    mech_science_name = "波导机甲",
    env_passive_name = "人造环境",
    env_passive_description = "终止标记方格内的单位行动并造成 %d 点结算伤害。所有单位都能察觉到危险并避开人造环境。",
    env_passive_basic_description = "终止标记方格内的单位行动并造成 3 点基础伤害。所有单位都能察觉到危险并避开人造环境。",
    env_overload_disabled = "过载失败",
    env_passive_disabled = "环境加载器无法工作。",
    env_airsupport_title = "空中支援",
    env_airsupport_text = "无法操纵当前环境，请求阿凯夫空中支援。",
    action_terminated = "行动终止",
    add_to_shop = "添加%s到商店"
}
